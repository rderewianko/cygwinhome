#!/bin/ksh
platform=`uname`
HOST=`hostname`
if [ "${HOST}" = "serenity" ]
then
	/usr/openwin/bin/xrdb -merge /home/ujmj003/.Xdefaults >/dev/null 2>&1
        /usr/openwin/bin/xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/ksh
elif [ "${HOST}" = "vsmn00zk00112" ]
then
        /usr/openwin/bin/xrdb -merge /home/ujmj003/.Xdefaults >/dev/null 2>&1
        /usr/openwin/bin/xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/ksh
elif [ "${HOST}" = "caprica" ]
then
	/usr/bin/xrdb -merge /home/ujmj003/.Xdefaults >/dev/null 2>&1
        /usr/bin/xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/bash
elif [ "${HOST}" = "LWMN00X191566" ]
then
        /usr/X11R6/bin/xrdb -merge /home/ujmj003/.Xdefaults >/dev/null 2>&1
        /uxr/bin/xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/bash
else
        echo "Unexpected platform, using defaults"
        xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/ksh
fi

#if [ "${platform}" = "SunOS" ]
#then
#	/usr/openwin/bin/xrdb -merge /home/ujmj003/.Xdefaults >/dev/null 2>&1
#	/usr/openwin/bin/xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/ksh
#elif [ "${platform}" = "Linux" ]
#then
#	/usr/bin/xrdb -merge /home/ujmj003/.Xdefaults >/dev/null 2>&1 
#	/usr/bin/xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/bash
#elif [ "${platform}" = "CYGWIN_NT-5.1" ]
#then
#	/usr/X11R6/bin/xrdb -merge /home/ujmj003/.Xdefaults >/dev/null 2>&1
#	/uxr/bin/xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/bash
#else
#	echo "Unexpected platform, using defaults"
#	xterm -sb -sl 2500 -bg slategray -fg black -geometry 35x5+1043+0 -e /usr/bin/ksh
#fi
