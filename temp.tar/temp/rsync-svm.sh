#!/bin/ksh
### CRONTAB ENTRY ###
# rsync to new svm file systems can be removed after 5/10/09
#30 * * * * /var/tmp/rsync-svm.sh > /tmp/svmrsync.out 2>&1
###
/usr/local/bin/rsync -av -e --delete --force /opt/ISS/ /new_ISS
sleep 60
/usr/local/bin/rsync -av -e --delete --force /opt/tuxedo81/ /new_tuxedo81
sleep 60
/usr/local/bin/rsync -av -e --delete --force /u01/ /new_u01
sleep 60
/usr/local/bin/rsync -av -e --delete --force /opt/psoft/ /new_psoft
