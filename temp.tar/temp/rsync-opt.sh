#!/bin/ksh
### NOT NEEDED CRONTAB ENTRY ###
# rsync to new svm file systems can be removed after 5/10/09
#30 * * * * /var/tmp/rsync-svm.sh > /tmp/svmrsync.out 2>&1
### NOT NEEDED
echo "/opt/SUNWits..."
/usr/local/bin/rsync -av -e --delete --force /opt/SUNWits /temp_opt/ &
sleep 30
echo "/opt/SUNWrtvc..."
/usr/local/bin/rsync -av -e --delete --force /opt/SUNWrtvc /temp_opt/ &
sleep 30
echo "/opt/cssaudit..."
/usr/local/bin/rsync -av -e --delete --force /opt/cssaudit /temp_opt/ &
sleep 30
echo "/opt/SUNWscat..."
/usr/local/bin/rsync -av -e --delete --force /opt/SUNWscat /temp_opt/ &
sleep 30
echo "/opt/SUNWvts..."
/usr/local/bin/rsync -av -e --delete --force /opt/SUNWvts /temp_opt/ &
sleep 30
echo "/opt/local..."
/usr/local/bin/rsync -av -e --delete --force /opt/local /temp_opt/ &
sleep 30
echo "/opt/hpnpl..."
/usr/local/bin/rsync -av -e --delete --force /opt/hpnpl /temp_opt/ &
sleep 30
echo "/opt/SUNWcstu..."
/usr/local/bin/rsync -av -e --delete --force /opt/SUNWcstu /temp_opt/ &
sleep 30
echo "/opt/perf..."
/usr/local/bin/rsync -av -e --delete --force /opt/perf /temp_opt/ &
sleep 30
echo "/opt/dcelocal..."
/usr/local/bin/rsync -av -e --delete --force /opt/dcelocal /temp_opt/ &
sleep 30
echo "/opt/OV..."
/usr/local/bin/rsync -av -e --delete --force /opt/OV /temp_opt/ &
sleep 30
echo "/opt/rce..."
/usr/local/bin/rsync -av -e --delete --force /opt/rce /temp_opt/ &
sleep 30
echo "/opt/SUNWsymon..."
/usr/local/bin/rsync -av -e --delete --force /opt/SUNWsymon /temp_opt/ &
sleep 30
echo "/opt/mirror..."
/usr/local/bin/rsync -av -e --delete --force /opt/mirror /temp_opt/ &
sleep 30
echo "/opt/patrol..."
/usr/local/bin/rsync -av -e --delete --force /opt/patrol /temp_opt/ &
sleep 30
echo "/opt/JNIC146x..."
/usr/local/bin/rsync -av -e --delete --force /opt/JNIC146x /temp_opt/ &
sleep 30
echo "/opt/JNIsnia..."
/usr/local/bin/rsync -av -e --delete --force /opt/JNIsnia /temp_opt/ &
sleep 30
echo "/opt/jni..."
/usr/local/bin/rsync -av -e --delete --force /opt/jni /temp_opt/ &
sleep 30
echo "/opt/SM8..."
/usr/local/bin/rsync -av -e --delete --force /opt/SM8 /temp_opt/ &
sleep 30
echo "/opt/sdk..."
/usr/local/bin/rsync -av -e --delete --force /opt/sdk /temp_opt/ &
sleep 30
echo "/opt/QLogic_Corporation..."
/usr/local/bin/rsync -av -e --delete --force /opt/QLogic_Corporation /temp_opt/ &
sleep 30
echo "/opt/nsr..."
/usr/local/bin/rsync -av -e --delete --force /opt/nsr /temp_opt/ &
#
### Recreate Symlink that resides in /opt in /temp_opt
#
ln -s /opt/SUNWfm /temp_opt/SUNWfm
chgrp -h other /temp_opt/SUNWfm
