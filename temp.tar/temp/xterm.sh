#!/usr/bin/ksh
/usr/openwin/bin/xrdb -merge /home/uss/ujmj003/.Xdefaults
exec xterm -ls -sl 2500 -sb -bg black -fg green -geometry 100x30 &
