#!/bin/bash
#/usr/openwin/bin/xrdb -merge /home/uss/ujmj003/.Xresources
#xmodmap -e "pointer = 1 3 2 4 5"
#xhost + > /dev/null

case $1 in
	'black')
		xterm -sl 8500 -bg black -fg green -geometry 100x30 -sb -e /usr/bin/ksh &
		exit 0
		;;
	'steel')
		xterm -sl 8500 -bg black -fg steelblue -geometry 100x30 -e /usr/bin/ksh &
		exit 0
		;;
	'orange')
		xterm -sl 8500 -bg black -fg orange -geometry 100x30 -sb -e /usr/bin/ksh &
		exit 0
		;;
	'pink')
		xterm -sl 8500 -bg black -fg pink -geometry 100x30 -sb -e /usr/bin/ksh &
		exit 0
		;;
	'slate')
		xterm -sl 8500 -bg black -fg slategray -geometry 100x30 -sb -e /usr/bin/ksh &
		exit 0
		;;
	'olive')
		xterm -sl 8500 -bg black -fg olivedrab -geometry 100x30 -sb -e /usr/bin/ksh &
		exit 0
		;;
	'red')
		xterm -sl 8500 -bg black -fg red -geometry 100x30 -sb -e /usr/bin/ksh &
		exit 0
		;;
	*)
		echo "USAGE: $0 { black | steel | orange | pink | slate | olive | red }"
		exit 1
		;;
esac

exit 0
